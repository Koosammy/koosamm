import { defineConfig } from 'astro/config';

// https://astro.build/config
export default defineConfig({
  // Update these values with your actual GitHub username and repository name
  site: 'https://yourusername.github.io',
  base: '/your-repo-name',
});